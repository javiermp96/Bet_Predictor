import { GoogleGenAI } from "@google/genai";
import { Match, Prediction } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function analyzeMatch(match: Match): Promise<Prediction> {
  const prompt = `
    Analiza el siguiente partido de fútbol y proporciona una predicción detallada para apuestas.
    Partido: ${match.homeTeam} vs ${match.awayTeam}
    Liga: ${match.league}
    Fecha: ${match.date}
    Cuotas actuales: Local ${match.odds.home}, Empate ${match.odds.draw}, Visitante ${match.odds.away}

    Por favor, utiliza tus capacidades de búsqueda para encontrar resultados recientes de ambos equipos, enfrentamientos directos (H2H), lesiones importantes y estado de forma.

    Devuelve la respuesta en formato JSON con la siguiente estructura:
    {
      "matchId": "${match.id}",
      "prediction": "Resultado principal recomendado",
      "confidence": número del 0 al 100,
      "reasoning": "Explicación detallada de por qué esta apuesta es valiosa",
      "suggestedBet": "La apuesta específica a realizar (ej: Gana Local, Más de 2.5 goles)",
      "probability": {
        "home": porcentaje,
        "draw": porcentaje,
        "away": porcentaje
      }
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
      },
    });

    const result = JSON.parse(response.text || "{}");
    return result as Prediction;
  } catch (error) {
    console.error("Error analyzing match:", error);
    throw error;
  }
}

export async function getUpcomingMatches(): Promise<Match[]> {
  // En una app real, esto vendría de una API de fútbol.
  // Aquí usaremos Gemini para "descubrir" partidos importantes próximos si no tenemos API.
  // Pero para el demo, proporcionaremos una lista base que Gemini puede analizar.
  
  const today = new Date().toISOString().split('T')[0];
  
  return [
    {
      id: "1",
      homeTeam: "Real Madrid",
      awayTeam: "Barcelona",
      league: "La Liga",
      date: today,
      time: "21:00",
      odds: { home: 2.10, draw: 3.40, away: 3.20 }
    },
    {
      id: "2",
      homeTeam: "Manchester City",
      awayTeam: "Liverpool",
      league: "Premier League",
      date: today,
      time: "18:30",
      odds: { home: 1.85, draw: 3.80, away: 4.00 }
    },
    {
      id: "3",
      homeTeam: "Bayern Munich",
      awayTeam: "Borussia Dortmund",
      league: "Bundesliga",
      date: today,
      time: "15:30",
      odds: { home: 1.45, draw: 4.75, away: 6.50 }
    },
    {
      id: "4",
      homeTeam: "Inter Milan",
      awayTeam: "Juventus",
      league: "Serie A",
      date: today,
      time: "20:45",
      odds: { home: 2.05, draw: 3.25, away: 3.90 }
    }
  ];
}
