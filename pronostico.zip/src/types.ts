export interface Match {
  id: string;
  homeTeam: string;
  awayTeam: string;
  league: string;
  date: string;
  time: string;
  odds: {
    home: number;
    draw: number;
    away: number;
  };
}

export interface Prediction {
  matchId: string;
  prediction: string; // e.g., "Home Win", "Over 2.5 Goals"
  confidence: number; // 0-100
  reasoning: string;
  suggestedBet: string;
  probability: {
    home: number;
    draw: number;
    away: number;
  };
}

export interface MatchAnalysis extends Match {
  prediction?: Prediction;
}
