import React, { useState, useEffect } from 'react';
import { Match, Prediction } from './types';
import { getUpcomingMatches, analyzeMatch } from './services/geminiService';
import { MatchCard } from './components/MatchCard';
import { LayoutGrid, TrendingUp, History, Settings, Bell, Search, Trophy, Target } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [matches, setMatches] = useState<Match[]>([]);
  const [predictions, setPredictions] = useState<Record<string, Prediction>>({});
  const [analyzingIds, setAnalyzingIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    async function init() {
      try {
        const data = await getUpcomingMatches();
        setMatches(data);
      } catch (error) {
        console.error("Error fetching matches:", error);
      } finally {
        setLoading(false);
      }
    }
    init();
  }, []);

  const handleAnalyze = async (match: Match) => {
    if (analyzingIds.has(match.id)) return;

    setAnalyzingIds(prev => new Set(prev).add(match.id));
    try {
      const prediction = await analyzeMatch(match);
      setPredictions(prev => ({ ...prev, [match.id]: prediction }));
    } catch (error) {
      console.error("Error analyzing match:", error);
    } finally {
      setAnalyzingIds(prev => {
        const next = new Set(prev);
        next.delete(match.id);
        return next;
      });
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="h-16 border-b border-bet-border bg-bet-dark/80 backdrop-blur-md sticky top-0 z-50 px-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-bet-green rounded flex items-center justify-center">
            <Trophy size={20} className="text-black" />
          </div>
          <h1 className="text-xl font-bold tracking-tighter">
            FUTBOL<span className="text-bet-green">PREDICTOR</span> AI
          </h1>
        </div>

        <div className="hidden md:flex items-center gap-6">
          <nav className="flex items-center gap-4">
            <button className="text-sm font-medium text-bet-green border-b-2 border-bet-green pb-1">En Vivo</button>
            <button className="text-sm font-medium text-gray-400 hover:text-white transition-colors">Próximos</button>
            <button className="text-sm font-medium text-gray-400 hover:text-white transition-colors">Resultados</button>
          </nav>
        </div>

        <div className="flex items-center gap-4">
          <button className="p-2 text-gray-400 hover:text-white transition-colors">
            <Search size={20} />
          </button>
          <button className="p-2 text-gray-400 hover:text-white transition-colors relative">
            <Bell size={20} />
            <span className="absolute top-1 right-1 w-2 h-2 bg-bet-green rounded-full"></span>
          </button>
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-bet-green to-emerald-600 flex items-center justify-center text-black font-bold text-xs">
            JM
          </div>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <aside className="w-64 border-r border-bet-border hidden lg:flex flex-col p-4 gap-2">
          <div className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-2 px-2">Navegación</div>
          <button className="flex items-center gap-3 p-3 rounded-lg bg-bet-green/10 text-bet-green font-medium">
            <LayoutGrid size={18} />
            Dashboard
          </button>
          <button className="flex items-center gap-3 p-3 rounded-lg text-gray-400 hover:bg-white/5 transition-colors">
            <Target size={18} />
            Value Bets
          </button>
          <button className="flex items-center gap-3 p-3 rounded-lg text-gray-400 hover:bg-white/5 transition-colors">
            <TrendingUp size={18} />
            Tendencias
          </button>
          <button className="flex items-center gap-3 p-3 rounded-lg text-gray-400 hover:bg-white/5 transition-colors">
            <History size={18} />
            Mi Historial
          </button>
          
          <div className="mt-8 text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-2 px-2">Ligas Top</div>
          <div className="flex flex-col gap-1">
            {['La Liga', 'Premier League', 'Champions League', 'Bundesliga', 'Serie A'].map(league => (
              <button key={league} className="flex items-center justify-between p-2 rounded-lg text-sm text-gray-400 hover:bg-white/5 transition-colors">
                <span>{league}</span>
                <span className="text-[10px] bg-white/10 px-1.5 py-0.5 rounded">12</span>
              </button>
            ))}
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto p-6 bg-bet-dark">
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
              <div>
                <h2 className="text-2xl font-bold mb-1">Partidos Destacados</h2>
                <p className="text-gray-400 text-sm">Análisis de IA basado en datos históricos y forma actual.</p>
              </div>
              
              <div className="flex bg-bet-card p-1 rounded-lg border border-bet-border">
                <button 
                  onClick={() => setFilter('all')}
                  className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all ${filter === 'all' ? 'bg-bet-green text-black' : 'text-gray-400'}`}
                >
                  Todos
                </button>
                <button 
                  onClick={() => setFilter('high')}
                  className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all ${filter === 'high' ? 'bg-bet-green text-black' : 'text-gray-400'}`}
                >
                  Alta Confianza
                </button>
              </div>
            </div>

            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3, 4, 5, 6].map(i => (
                  <div key={i} className="h-80 bg-bet-card border border-bet-border rounded-xl animate-pulse"></div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <AnimatePresence mode="popLayout">
                  {matches.map((match) => (
                    <MatchCard
                      key={match.id}
                      match={match}
                      prediction={predictions[match.id]}
                      onAnalyze={handleAnalyze}
                      isAnalyzing={analyzingIds.has(match.id)}
                    />
                  ))}
                </AnimatePresence>
              </div>
            )}

            {/* Stats Section */}
            <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="glass-panel p-6 flex flex-col gap-2">
                <div className="text-gray-400 text-xs font-bold uppercase tracking-wider">Tasa de Acierto IA</div>
                <div className="text-3xl font-bold text-bet-green">84.2%</div>
                <div className="text-[10px] text-gray-500">Basado en los últimos 500 pronósticos</div>
              </div>
              <div className="glass-panel p-6 flex flex-col gap-2">
                <div className="text-gray-400 text-xs font-bold uppercase tracking-wider">ROI Promedio</div>
                <div className="text-3xl font-bold text-bet-green">+12.5%</div>
                <div className="text-[10px] text-gray-500">Retorno de inversión mensual</div>
              </div>
              <div className="glass-panel p-6 flex flex-col gap-2">
                <div className="text-gray-400 text-xs font-bold uppercase tracking-wider">Apuestas Analizadas</div>
                <div className="text-3xl font-bold text-bet-green">12,482</div>
                <div className="text-[10px] text-gray-500">Temporada 2024/2025</div>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Footer */}
      <footer className="p-4 border-t border-bet-border bg-bet-dark text-center text-[10px] text-gray-500 uppercase tracking-widest">
        © 2026 FutbolPredictor AI • Juega con responsabilidad • +18
      </footer>
    </div>
  );
}
